import React from 'react';
import clsx from 'clsx';

var styles = {"selectContainer":"_3Ifyx","select":"_1ul-b","option":"_3tQrm","arrow":"_35l6Q"};

var Dropdown = function Dropdown(_ref) {
  var options = _ref.options,
      handleSelect = _ref.handleSelect,
      containerClass = _ref.containerClass,
      selectClass = _ref.selectClass,
      arrowClass = _ref.arrowClass;
  return React.createElement("div", {
    className: clsx(styles.selectContainer, containerClass)
  }, React.createElement("select", {
    className: clsx(styles.select, selectClass),
    onChange: function onChange(event) {
      return handleSelect(event.target.value);
    }
  }, options.map(function (_ref2, index) {
    var name = _ref2.name,
        value = _ref2.value;
    return React.createElement("option", {
      className: clsx(styles.option),
      key: index,
      value: value
    }, name);
  })), React.createElement("span", {
    className: clsx(styles.arrow, arrowClass),
    tabIndex: 0
  }));
};

export { Dropdown };
//# sourceMappingURL=index.modern.js.map
