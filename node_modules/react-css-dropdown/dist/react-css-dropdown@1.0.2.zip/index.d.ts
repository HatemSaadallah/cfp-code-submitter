import React from 'react';
interface Props {
    containerClass?: string;
    selectClass?: string;
    arrowClass?: string;
    options: {
        name: string;
        value: string | number;
    }[];
    handleSelect: (value: string) => string | any;
}
export declare const Dropdown: React.FunctionComponent<Props>;
export {};
